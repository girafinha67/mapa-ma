package com.mapama

import java.util.concurrent.Executors

class NavigationEngine(
    private val router: Router,
    private val onRota: (Rota) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onInstrucao: (String) -> Unit,
    private val limiteMetros: Double = 30.0,
    private val fixesParaDesvio: Int = 3
) {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var destino: Pt? = null
    @Volatile private var rota: Rota? = null
    private var foraDaRota = 0
    @Volatile private var calculando = false

    val ativo get() = destino != null

    fun iniciar(origem: Pt, dest: Pt) { destino = dest; rota = null; foraDaRota = 0; calcular(origem) }
    fun parar() { destino = null; rota = null; foraDaRota = 0 }

    /** Posição "grudada" na rota (só se estiver a até 25 m dela); senão null. Usado só para exibir. */
    fun projetar(p: Pt): Pt? {
        val r = rota ?: return null
        val (q, d) = Geo.projetar(p, r.pontos) ?: return null
        return if (d <= 25.0) q else null
    }

    fun onLocalizacao(p: Pt, precisaoM: Float = 0f) {
        if (destino == null) return
        val r = rota ?: return
        // leituras com erro grande (>40 m) não contam como "fora da rota"
        if (precisaoM <= 40f) {
            if (Geo.distToPolyline(p, r.pontos) > limiteMetros) foraDaRota++ else foraDaRota = 0
        }
        if (foraDaRota >= fixesParaDesvio && !calculando) {
            foraDaRota = 0; onStatus("Recalculando rota…"); calcular(p); return
        }
        val idx = Geo.indiceMaisProximo(p, r.pontos)
        val restante = Geo.distAoLongo(r.pontos, idx, r.pontos.size - 1)
        if (restante < 25) { onStatus("Você chegou ao destino"); parar(); return }
        val prox = r.manobras.firstOrNull { it.indice > idx }
        if (prox != null) {
            val m = Geo.distAoLongo(r.pontos, idx, prox.indice)
            onInstrucao("${prox.texto}\nem ${Geo.formatarDistancia(m)}  ·  faltam ${Geo.formatarDistancia(restante)}")
        }
    }

    private fun calcular(origem: Pt) {
        val d = destino ?: return
        calculando = true
        exec.execute {
            try {
                val r = router.rota(origem, d)
                if (r != null) { rota = r; onRota(r) } else onStatus("Sem rota encontrada")
            } catch (e: Throwable) { onStatus("Erro na rota: ${e.message}") }
            finally { calculando = false }
        }
    }
}
