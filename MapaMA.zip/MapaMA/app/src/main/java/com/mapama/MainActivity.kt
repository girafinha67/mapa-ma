package com.mapama

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.valhalla.valhalla.Valhalla
import com.valhalla.valhalla.config.ValhallaConfigBuilder
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.gestures.MoveGestureDetector
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import java.io.File

class MainActivity : AppCompatActivity(), LocationListener {
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private lateinit var status: TextView
    private lateinit var lista: ListView
    private lateinit var btnCancelar: Button
    private var busca: SearchDb? = null
    private var engine: NavigationEngine? = null
    private var posicao: Pt? = null
    private var pendente: Pt? = null
    private var seguir = true
    private var gpsAtivo = false
    private val seletor = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importar(uris)
    }
    private var fused: FusedLocationProviderClient? = null
    private val fusedCallback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let { onNovaPosicao(it) } }
    }

    @Volatile private var valhalla: Valhalla? = null
    private val dados get() = getExternalFilesDir(null)!!

    /** Cria o motor de rotas uma única vez (pesado), sempre fora da thread principal. */
    private fun valhalla(): Valhalla = valhalla ?: synchronized(this) {
        valhalla ?: run {
            val tar = File(dados, "valhalla_tiles.tar")
            check(tar.exists()) { "Falta valhalla_tiles.tar em ${dados.path}" }
            val config = ValhallaConfigBuilder().withTileExtract(tar.absolutePath).build()
            Valhalla(applicationContext, config)
        }.also { valhalla = it }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        MapLibre.getInstance(this)

        val raiz = FrameLayout(this)
        mapView = MapView(this).also { raiz.addView(it) }

        val topo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEEFFFFFF.toInt()) }
        val campo = EditText(this).apply { hint = "Buscar lugar, rua ou bairro…"; setSingleLine() }
        lista = ListView(this).apply { visibility = ListView.GONE }
        topo.addView(campo); topo.addView(lista, LinearLayout.LayoutParams(-1, 600))
        raiz.addView(topo, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(24, 48, 24, 0) })

        val base = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val botoes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        btnCancelar = Button(this).apply { text = "✕ Parar"; visibility = Button.GONE; setOnClickListener { cancelar() } }
        val btnCentro = Button(this).apply {
            text = "◎ Centralizar"
            setOnClickListener { seguir = true; posicao?.let { map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(it.lat, it.lon), 16.0)) } }
        }
        val btnImportar = Button(this).apply { text = "⬇ Importar dados"; setOnClickListener { seletor.launch(arrayOf("*/*")) } }
        botoes.addView(btnImportar); botoes.addView(btnCancelar); botoes.addView(btnCentro)
        status = TextView(this).apply {
            setBackgroundColor(0xEE000000.toInt()); setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setPadding(32, 24, 32, 24); visibility = TextView.GONE
        }
        base.addView(botoes); base.addView(status, LinearLayout.LayoutParams(-1, -2))
        raiz.addView(base, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(raiz)

        val dbFile = File(dados, "busca.db")
        if (dbFile.exists()) busca = SearchDb(dbFile.path) else aviso("Faltam os dados. Toque em ⬇ Importar dados e escolha os 3 arquivos.")

        campo.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val r = busca?.buscar(s.toString()) ?: emptyList()
                lista.visibility = if (r.isEmpty()) ListView.GONE else ListView.VISIBLE
                lista.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, r)
                lista.setOnItemClickListener { _, _, i, _ ->
                    lista.visibility = ListView.GONE
                    campo.setText(""); campo.clearFocus()
                    irPara(r[i])
                }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            val mb = File(dados, "maranhao.mbtiles")
            if (!mb.exists()) { aviso("Faltam os dados. Toque em ⬇ Importar dados e escolha os 3 arquivos."); return@getMapAsync }
            val json = assets.open("style.json").bufferedReader().readText().replace("__MBTILES__", mb.absolutePath)
            m.setStyle(Style.Builder().fromJson(json)) { st ->
                st.addSource(GeoJsonSource("rota"))
                st.addSource(GeoJsonSource("destino"))
                st.addSource(GeoJsonSource("eu"))
                st.addLayer(LineLayer("rota-linha", "rota").withProperties(lineColor(0xFF1A73E8.toInt()), lineWidth(6f), lineCap("round"), lineJoin("round")))
                st.addLayer(CircleLayer("destino-pino", "destino").withProperties(circleRadius(9f), circleColor(0xFFD93025.toInt()), circleStrokeColor(0xFFFFFFFF.toInt()), circleStrokeWidth(3f)))
                st.addLayer(CircleLayer("eu-ponto", "eu").withProperties(circleRadius(8f), circleColor(0xFF1A73E8.toInt()), circleStrokeColor(0xFFFFFFFF.toInt()), circleStrokeWidth(3f)))
            }
            m.cameraPosition = CameraPosition.Builder().target(LatLng(-2.53, -44.30)).zoom(11.0).build() // São Luís
            m.addOnMoveListener(object : MapLibreMap.OnMoveListener {
                override fun onMoveBegin(d: MoveGestureDetector) { seguir = false }
                override fun onMove(d: MoveGestureDetector) {}
                override fun onMoveEnd(d: MoveGestureDetector) {}
            })
        }

        engine = NavigationEngine(
            ValhallaRouter { req -> valhalla().routeRaw(req) },
            onRota = { r -> runOnUiThread { desenharRota(r); aviso("%.1f km · %.0f min".format(r.distanciaKm, r.minutos)) } },
            onStatus = { s -> runOnUiThread { aviso(s); if (s.startsWith("Você chegou")) limparRota() } },
            onInstrucao = { t -> runOnUiThread { aviso(t) } })

        pedirGps()
    }

    private fun nomeDe(u: Uri): String? =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }

    /** Copia os arquivos escolhidos (baixados em Downloads) para a pasta de dados do app. */
    private fun importar(uris: List<Uri>) {
        aviso("Importando…")
        Thread {
            try {
                for (u in uris) {
                    val nome = (nomeDe(u) ?: "").lowercase()
                    val destino = when {
                        nome.endsWith(".mbtiles") -> "maranhao.mbtiles"
                        nome.endsWith(".tar") -> "valhalla_tiles.tar"
                        nome.endsWith(".db") -> "busca.db"
                        else -> null
                    } ?: continue
                    val tmp = File(dados, "$destino.tmp")
                    val entrada = contentResolver.openInputStream(u) ?: continue
                    entrada.use { inp ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20); var total = 0L; var n: Int
                            while (inp.read(buf).also { n = it } > 0) {
                                out.write(buf, 0, n); total += n
                                if ((total shr 20) % 20L == 0L) runOnUiThread { aviso("Copiando $destino… ${total shr 20} MB") }
                            }
                        }
                    }
                    File(dados, destino).delete(); tmp.renameTo(File(dados, destino))
                }
                runOnUiThread { aviso("Importação concluída. Reiniciando…"); recreate() }
            } catch (e: Throwable) { runOnUiThread { aviso("Erro ao importar: ${e.message}") } }
        }.start()
    }

    private fun irPara(l: Lugar) {
        val dest = Pt(l.lat, l.lon)
        map?.style?.getSourceAs<GeoJsonSource>("destino")?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(l.lon, l.lat)))
        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(l.lat, l.lon), 15.0))
        btnCancelar.visibility = Button.VISIBLE
        val o = posicao
        if (o == null) { pendente = dest; aviso("Aguardando sinal de GPS…") }
        else { seguir = true; aviso("Calculando rota…"); engine?.iniciar(o, dest) }
    }

    private fun desenharRota(r: Rota) {
        val line = LineString.fromLngLats(r.pontos.map { Point.fromLngLat(it.lon, it.lat) })
        map?.style?.getSourceAs<GeoJsonSource>("rota")?.setGeoJson(Feature.fromGeometry(line))
    }

    private fun limparRota() {
        map?.style?.getSourceAs<GeoJsonSource>("rota")?.setGeoJson(FeatureCollection.fromFeatures(emptyList<Feature>()))
        map?.style?.getSourceAs<GeoJsonSource>("destino")?.setGeoJson(FeatureCollection.fromFeatures(emptyList<Feature>()))
        btnCancelar.visibility = Button.GONE
    }

    private fun cancelar() { engine?.parar(); pendente = null; limparRota(); status.visibility = TextView.GONE }

    private fun aviso(t: String) { status.text = t; status.visibility = TextView.VISIBLE }

    @SuppressLint("MissingPermission")
    private fun pedirGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1); return
        }
        if (gpsAtivo) return
        gpsAtivo = true
        val temPlayServices = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == ConnectionResult.SUCCESS
        if (temPlayServices) {
            // Combina GPS + sensores do celular; funciona offline.
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L).setMinUpdateIntervalMillis(500L).build()
            fused = LocationServices.getFusedLocationProviderClient(this).also {
                it.requestLocationUpdates(req, fusedCallback, mainLooper)
            }
        } else {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager)
                .requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(c, p, g); pedirGps()
    }

    override fun onLocationChanged(loc: Location) = onNovaPosicao(loc)

    private fun onNovaPosicao(loc: Location) {
        val bruto = Pt(loc.latitude, loc.longitude); posicao = bruto
        // Durante a navegação, o ponto azul é "grudado" na rota (só visual); a lógica usa a posição bruta.
        val exibido = engine?.projetar(bruto) ?: bruto
        map?.style?.getSourceAs<GeoJsonSource>("eu")?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(exibido.lon, exibido.lat)))
        if (seguir) map?.animateCamera(CameraUpdateFactory.newLatLng(LatLng(exibido.lat, exibido.lon)))
        pendente?.let { pendente = null; aviso("Calculando rota…"); engine?.iniciar(bruto, it) }
        engine?.onLocalizacao(bruto, loc.accuracy)
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { super.onPause(); mapView.onPause() }
    override fun onStop() { super.onStop(); mapView.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() {
        super.onDestroy(); mapView.onDestroy(); valhalla?.close()
        fused?.removeLocationUpdates(fusedCallback)
        (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
    }
    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); mapView.onSaveInstanceState(o) }
}
