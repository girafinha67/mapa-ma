package com.mapama

import kotlin.math.*

data class Pt(val lat: Double, val lon: Double)

object Geo {
    /** Decodifica polyline com precisão 6 (formato do Valhalla). */
    fun decodePolyline6(s: String): List<Pt> {
        val out = ArrayList<Pt>()
        var i = 0; var lat = 0; var lon = 0
        while (i < s.length) {
            var r = 0; var sh = 0; var b: Int
            do { b = s[i++].code - 63; r = r or ((b and 0x1f) shl sh); sh += 5 } while (b >= 0x20)
            lat += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            r = 0; sh = 0
            do { b = s[i++].code - 63; r = r or ((b and 0x1f) shl sh); sh += 5 } while (b >= 0x20)
            lon += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            out.add(Pt(lat / 1e6, lon / 1e6))
        }
        return out
    }

    fun haversine(a: Pt, b: Pt): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(b.lat - a.lat); val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }

    /** Distância em metros do ponto p até a polilinha (aprox. equirretangular, ok p/ distâncias curtas). */
    fun distToPolyline(p: Pt, line: List<Pt>): Double {
        if (line.size < 2) return Double.MAX_VALUE
        val kx = 111320.0 * cos(Math.toRadians(p.lat)); val ky = 110540.0
        var best = Double.MAX_VALUE
        for (i in 0 until line.size - 1) {
            val ax = (line[i].lon - p.lon) * kx; val ay = (line[i].lat - p.lat) * ky
            val bx = (line[i + 1].lon - p.lon) * kx; val by = (line[i + 1].lat - p.lat) * ky
            val dx = bx - ax; val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
            best = min(best, hypot(ax + t * dx, ay + t * dy))
        }
        return best
    }

    /** Ponto da rota mais próximo de p e a distância até ele (m). */
    fun projetar(p: Pt, line: List<Pt>): Pair<Pt, Double>? {
        if (line.size < 2) return null
        val kx = 111320.0 * cos(Math.toRadians(p.lat)); val ky = 110540.0
        var best: Pt? = null; var bd = Double.MAX_VALUE
        for (i in 0 until line.size - 1) {
            val ax = (line[i].lon - p.lon) * kx; val ay = (line[i].lat - p.lat) * ky
            val bx = (line[i + 1].lon - p.lon) * kx; val by = (line[i + 1].lat - p.lat) * ky
            val dx = bx - ax; val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
            val d = hypot(ax + t * dx, ay + t * dy)
            if (d < bd) {
                bd = d
                best = Pt(line[i].lat + t * (line[i + 1].lat - line[i].lat), line[i].lon + t * (line[i + 1].lon - line[i].lon))
            }
        }
        return best?.let { it to bd }
    }

    /** Índice do vértice da rota mais próximo de p. */
    fun indiceMaisProximo(p: Pt, line: List<Pt>): Int {
        var best = 0; var bd = Double.MAX_VALUE
        for (i in line.indices) { val d = haversine(p, line[i]); if (d < bd) { bd = d; best = i } }
        return best
    }

    /** Distância (m) percorrendo a rota do vértice [de] até o vértice [ate]. */
    fun distAoLongo(line: List<Pt>, de: Int, ate: Int): Double {
        var s = 0.0
        for (i in de until min(ate, line.size - 1)) s += haversine(line[i], line[i + 1])
        return s
    }

    fun formatarDistancia(m: Double): String =
        if (m < 1000) "${(m / 10).roundToInt() * 10} m" else "%.1f km".format(m / 1000)
}
