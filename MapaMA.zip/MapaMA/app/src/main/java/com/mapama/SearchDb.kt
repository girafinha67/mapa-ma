package com.mapama

import android.database.sqlite.SQLiteDatabase

data class Lugar(val nome: String, val tipo: String, val lat: Double, val lon: Double) {
    override fun toString() = if (tipo.isBlank()) nome else "$nome  ·  $tipo"
}

class SearchDb(path: String) {
    private val db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY)

    fun buscar(texto: String, limite: Int = 20): List<Lugar> {
        val termos = texto.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .joinToString(" ") { "\"" + it.replace("\"", "") + "\"*" }
        if (termos.isEmpty()) return emptyList()
        val out = ArrayList<Lugar>()
        db.rawQuery(
            "SELECT nome, tipo, lat, lon FROM lugares WHERE lugares MATCH ? ORDER BY rank LIMIT ?",
            arrayOf(termos, limite.toString())
        ).use { c ->
            while (c.moveToNext())
                out.add(Lugar(c.getString(0), c.getString(1), c.getString(2).toDouble(), c.getString(3).toDouble()))
        }
        return out
    }
}
