package com.mapama

import org.json.JSONArray
import org.json.JSONObject

data class Manobra(val texto: String, val indice: Int)
data class Rota(val pontos: List<Pt>, val distanciaKm: Double, val minutos: Double, val manobras: List<Manobra>)

interface Router {
    /** Rota mais rápida (offline). Chamar fora da thread principal. */
    fun rota(origem: Pt, destino: Pt): Rota?
}

/** [executar] recebe o JSON de requisição do Valhalla e devolve o JSON de resposta (Valhalla.routeRaw). */
class ValhallaRouter(private val executar: (String) -> String) : Router {
    override fun rota(origem: Pt, destino: Pt): Rota? {
        val req = JSONObject()
            .put("locations", JSONArray()
                .put(JSONObject().put("lat", origem.lat).put("lon", origem.lon))
                .put(JSONObject().put("lat", destino.lat).put("lon", destino.lon)))
            .put("costing", "auto")
            .put("directions_options", JSONObject().put("units", "kilometers").put("language", "pt-BR"))
        val resp = JSONObject(executar(req.toString()))
        val trip = resp.optJSONObject("trip") ?: return null
        val leg = trip.getJSONArray("legs").getJSONObject(0)
        val sum = trip.getJSONObject("summary")
        val manobras = ArrayList<Manobra>()
        leg.optJSONArray("maneuvers")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                manobras.add(Manobra(o.optString("instruction"), o.optInt("begin_shape_index")))
            }
        }
        return Rota(Geo.decodePolyline6(leg.getString("shape")), sum.getDouble("length"), sum.getDouble("time") / 60.0, manobras)
    }
}
