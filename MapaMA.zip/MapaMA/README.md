# Mapa MA — mapa e rotas 100% offline do Maranhão (Android)

## Passo a passo
1. No PC (Linux/WSL/Mac): `cd tools && bash build_dados.sh`
   - gera maranhao.mbtiles (mapa), valhalla_tiles.tar (rotas), busca.db (busca) e baixa as fontes dos nomes.
   - os tiles do Valhalla precisam ser da versão 3.6.x (a mesma do app).
2. Abra esta pasta no Android Studio e instale o app no celular (1ª vez só para criar a pasta de dados).
3. `adb push maranhao.mbtiles valhalla_tiles.tar busca.db /sdcard/Android/data/com.mapama/files/`
4. Abra o app, aceite o GPS, busque um lugar e toque nele: a rota aparece com instruções de curva.

## O que o app faz
- Mapa offline com ruas, água, prédios e nomes (cidades, bairros, ruas, locais).
- Busca offline (SQLite FTS5).
- Rota mais rápida (Valhalla embarcado) + instruções "vire à direita em 200 m".
- Recalcula sozinho se você sair da rota (30 m por 3 leituras de GPS).
- Localização em tempo real (GPS + sensores, funciona offline); durante a rota o ponto azul fica "grudado" na rua.
- Botões Parar e Centralizar; tela fica ligada.

## Se algo não compilar
- Import do `ValhallaConfigBuilder`: se o Android Studio marcar vermelho, use Alt+Enter e escolha o import certo.
- Versão do MapLibre: ajuste em app/build.gradle.kts.
