# Sem PC: tudo pelo celular

1. Crie conta em github.com e um repositório PÚBLICO (ex.: mapa-ma).
2. Add file > Upload files: envie o MapaMA.zip (sem descompactar).
3. Add file > Create new file: nome `.github/workflows/tudo.yml`, cole o conteúdo do arquivo tudo.yml e Commit.
4. Aba Actions > "Mapa MA" > Run workflow > acao = ambos.
5. Espere terminar (APK ~10 min; dados ~1 a 2 h). Em Releases baixe: app-debug.apk (release "apk") e os 3 arquivos (release "dados").
6. Instale o APK, abra o app, toque em "Importar dados" e escolha os 3 arquivos baixados.
