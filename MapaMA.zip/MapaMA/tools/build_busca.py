import sys, sqlite3, osmium

src, dst = sys.argv[1], sys.argv[2]
db = sqlite3.connect(dst)
db.execute("DROP TABLE IF EXISTS lugares")
db.execute("CREATE VIRTUAL TABLE lugares USING fts5(nome, tipo, lat UNINDEXED, lon UNINDEXED, tokenize='unicode61 remove_diacritics 2')")
vistos = set()

def add(nome, tipo, lat, lon):
    k = (nome, tipo, round(lat, 3), round(lon, 3))
    if k in vistos:
        return
    vistos.add(k)
    db.execute("INSERT INTO lugares VALUES (?,?,?,?)", (nome, tipo, lat, lon))

def tipo_de(t):
    return t.get("amenity") or t.get("shop") or t.get("tourism") or t.get("place") or t.get("highway") or ""

class H(osmium.SimpleHandler):
    def node(self, n):
        nome = n.tags.get("name")
        if nome and n.location.valid():
            add(nome, tipo_de(n.tags), n.location.lat, n.location.lon)
    def way(self, w):
        nome = w.tags.get("name")
        if nome and ("highway" in w.tags or "building" in w.tags or "amenity" in w.tags) and len(w.nodes) > 0:
            mid = w.nodes[len(w.nodes) // 2].location
            if mid.valid():
                add(nome, tipo_de(w.tags), mid.lat, mid.lon)

H().apply_file(src, locations=True)
db.commit()
db.close()
