#!/usr/bin/env bash
# Gera os dados offline do Maranhão. Rode com: bash build_dados.sh
# Requer: osmium-tool, java 17+, planetiler.jar (na mesma pasta), valhalla (valhalla_build_*), python3 + pyosmium, git
# IMPORTANTE: o app usa Valhalla 3.6.x. Gere os tiles com a MESMA versão (valhalla_build_tiles --version),
# senão o app pode não ler o valhalla_tiles.tar.
set -e
wget -nc https://download.geofabrik.de/south-america/brazil/nordeste-latest.osm.pbf
osmium extract -b -48.8,-10.3,-41.7,-1.0 nordeste-latest.osm.pbf -o maranhao.osm.pbf --overwrite

# 1) Mapa visual
java -Xmx6g -jar planetiler.jar --osm-path=maranhao.osm.pbf --output=maranhao.mbtiles --download --force

# 2) Rotas
mkdir -p valhalla_tiles
valhalla_build_config --mjolnir-tile-dir ./valhalla_tiles \
  --mjolnir-tile-extract ./valhalla_tiles.tar > valhalla.json
valhalla_build_tiles -c valhalla.json maranhao.osm.pbf
valhalla_build_extract -c valhalla.json -v

# 3) Busca
python3 build_busca.py maranhao.osm.pbf busca.db

# 4) Fontes para os nomes no mapa (vão dentro do APK, em app/src/main/assets/glyphs)
if [ ! -d ../app/src/main/assets/glyphs ]; then
  git clone --depth 1 https://github.com/kylebarron/openmaptiles-fonts fontes_tmp
  mkdir -p ../app/src/main/assets/glyphs
  cp -r "fontes_tmp/fonts/Noto Sans Regular" "fontes_tmp/fonts/Noto Sans Bold" ../app/src/main/assets/glyphs/ \
    || echo "ATENÇÃO: não achei as pastas 'Noto Sans Regular/Bold'; confira o conteúdo de fontes_tmp/fonts"
  rm -rf fontes_tmp
fi

echo
echo "Pronto. Envie para o celular (com o app já instalado uma vez):"
echo "adb push maranhao.mbtiles valhalla_tiles.tar busca.db /sdcard/Android/data/com.mapama/files/"
